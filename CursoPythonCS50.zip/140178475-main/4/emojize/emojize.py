import emoji

txt = input("Input: ").strip()
print(emoji.emojize(txt))
