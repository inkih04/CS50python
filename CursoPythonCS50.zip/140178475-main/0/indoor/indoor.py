text = input()
print(text.lower())