mass = input("m: ")
light = 300000000
print(f"E: {int(mass)*light**2}", end = "")