text = input()
print(text.replace(" ", "..."))